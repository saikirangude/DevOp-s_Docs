export JAVA_OPTS= "-Xms128m -Xmx1024m"
export JAVA_OPTS_123= "-Xms128m -Xmx1024m"
export JAVA_OPTS_12345= "-Xms128m -Xmx1024m"
